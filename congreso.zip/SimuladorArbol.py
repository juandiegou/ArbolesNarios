import pygame,sys
import ctypes
import tkinter as tk 
#from pygame.locals import *

class SimuladorArbol:
    azul= (0,128,128)
    amarillo= (255,255,0)
    rojo =(255,0,0)
    verde=(0,255,0)
    arbol=None
    listaBotones=[]
    def __init__(self,a):
        self.arbol=a



        
    def dibujar(self):

        user32 = ctypes.windll.user32
        user32.SetProcessDPIAware()
        pygame.init()
        ventana=pygame.display.set_mode((user32.GetSystemMetrics(0),user32.GetSystemMetrics(1)))
        ventana.fill((250,250,250))
        #boton =tkinter.Button(root,text="llamados", heigth=50)
       # boton.pack()
        while True:

            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
            pygame.display.update()           
