import pygame,sys
from ArbolNArio import ArbolNArio
from Nodo import Nodo
from Lector import Lector
from SimuladorArbol import SimuladorArbol




class main:
    congreso=None
    simulador=None
    arbol=None
    azul= (0,128,128)
    amarillo= (255,255,0)
    rojo =(255,0,0)
    verde=(0,255,0)
    def __init__(self):
        '''this is the main constructor'''
        l = Lector("format.json")
        self.congreso=l.getData()
        datoR=self.congreso['people'][0]['id']
        print(self.congreso['people'][0]['party'])
        c=self.congreso['people'][0]['party']
        self.arbol= ArbolNArio(datoR,c)
        #print("raiz: ",self.arbol.raiz.dato)
        #print(self.congreso['people'][0]['childrens'][0]['id'])
        for h in self.congreso['people'][0]['childrens']:
            self.arbol.agregar(self.arbol.raiz,self.arbol.raiz.dato,h['id'],h['party']) 
        self.llenado(self.arbol.raiz,self.congreso['people'][0]['childrens'])
        #self.arbol.anchura(self.arbol.raiz)
        #self.arbol.mostrar(self.arbol.raiz)
        self.simulador=SimuladorArbol(self.arbol)        
        self.simulador.dibujar()
        





    def llenado(self,d,l):
        '''d es Nodo -l es la lista de hijos.
           its can to full the treee'''
        if l==[]:
            return
        var=0
        for h in d.hijos:
            for k in l[var]['childrens']:
                self.arbol.agregar(self.arbol.raiz,h.dato,k['id'],k['party'])
                '''en esta linea debe ir la excecion de No tenr más de 4 hijos'''
            self.llenado(h,l[var]['childrens'])
            var+=1
      
      
        
        
            
                    
                





if __name__ == "__main__":
   main()