

class Nodo:
	def __init__(self,dato,color):
		self.dato=dato
		self.hijos = []
		self.color=color

	def agregarHijo(self,dato,color):
		self.hijos.append(Nodo(dato,color))
	

	def esHoja(self):
		return self.hijos==[]	




	def gradoNodo(self):
		return len(self.hijos)
	'''
	def agregarhijos(self,list):
		for h in list:
			self.agregarHijo(h)
	'''

	def cambio (self,dato ):
		self.dato=dato

	def setColor(self,color):
		self.color=color
