from Nodo import Nodo

class ArbolNArio:
	raiz= None
	def __init__(self,dato,color):
		self.raiz = Nodo (dato,color)

	def agregar(self,n,padre,dato,color):
		
		if  not n is None:
			#print("raiz", n.dato, " padre",padre," dato",dato)
			if n.dato== padre:
				#print("encontrado")
				n.agregarHijo(dato,color)
				#print("padre :",n.dato," hijo",dato)
				
			else:
				for h in n.hijos:
					self.agregar(h,padre,dato,color)

			
	def mostrar (self,n):
		
		if not n is None:			
			print("Nodo: ",n.dato,"\n")
			for h in n.hijos:
				print("Hijos de ",n.dato,":",h.dato,end="\n")
           
			for hh in n.hijos:
				self.mostrar(hh)


	def profundidad(self,r,d,n):
		if r is not None:
			if r.dato==d:
				print(n)
			else:
				for h in r.hijos:
					self.profundidad(h,d,n+1)
				n-=1
		
	def anchura(self,n):
		if n is not None:
			cola=[]
			temp=None
			cola.append(n)

			while len(cola)>0:
				temp=cola.pop(0)
				print(temp.dato,end=" ")
				for h in temp.hijos:
					cola.append(h)
				
            

	def altura(self,n):
		if n is None:
			return 0
		else:
			return 1+max((self.altura(h)for h in n.hijos),default=0)



	
	def obtenerRamas(self,n,lst, ls):
		''' n is the root -lst is the list of ways  -ls temporal list of Nodos. its can to obtain all ways '''
		if n is not  None:
			if n.hijos ==[]:
				lst.append(ls)
				ls.pop()
				return

			for h in n.Hijos:
				ls.append(h)
				self.obtenerRamas(h,lst,ls)
				ls.pop()

	def nivelNodo(self,r,d,l):
		'''r is the root -d is data. its can to obtain the level of data'''
		if r is not None:
			if r.dato == d:
				return l
			for h in r.Hijos:
				self.nivelNodo(h,d,l+1)

			